<?php 

class studentFunctions extends CI_Controller{

	public function student_login(){

		// $this->load->library('form_validation');
		// $this->form_validation->set_rules('uname','Uname','required|alpha');
		// $this->form_validation->set_rules('pword','Pword','required');
		// $this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
		// if($this->form_validation->run()==true)
		// {
			
			$uname=$this->input->post('uname');
			$pword=md5($this->input->post('pword'));
			
			$this->load->model('studentModel');

			$log_id=$this->studentModel->check_login($uname,$pword);
			If($log_id>=1){
				$this->load->library('session');
				$this->session->set_userdata('id',$log_id);
				$this->session->set_userdata('uname',$uname);
					
				$this->load->view('studentdashboard');

			}else{
 				echo ("Username or Password Error");
 			}
			// }else{
			// 	echo ('somethng is wrong');
			
 		// 	}
 } 
}