<?php

class teacherActivity extends CI_Controller{
	public function teacher_login(){

		// $this->load->library('form_validation');
		// $this->form_validation->set_rules('uname','Uname','required|alpha');
		// $this->form_validation->set_rules('pword','Pword','required');
		// $this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
		// if($this->form_validation->run()==true)
		// {
			
			$username=$this->input->post('username');
			$password=md5($this->input->post('pwd'));
			
			$this->load->model('teacherModel');

			$log_id=$this->teacherModel->login_valid($username,$password);
			If($log_id>=1){
				$this->load->library('session');
				$this->session->set_userdata('id',$log_id);
				$this->session->set_userdata('username',$username);
					
				$this->load->view('teacherdashboard');

			}else{
 				echo ("Username or Password Error");
 			}
			// }else{
			// 	echo ('somethng is wrong');
			
 		// 	}

}
}