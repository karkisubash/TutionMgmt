<?php

class studentModel extends CI_Model{

	public function check_login($uname,$pword)
	{
		
		$this->db->where('username', $uname);
		$this->db->where('password',$pword);
		$q=$this->db->get('tbl_student');
		
		//SELECT * FROM tbl_student WHERE username='$username' AND pword='$password';

		if ($q->num_rows()){
			return $q->row()->sid;
		}else{
			return false;
		}


	}




}