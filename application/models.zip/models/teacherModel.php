<?php

class teacherModel extends CI_Model{

	public function login_valid($username,$password)
	{
		
		$this->db->where('username', $username);
		$this->db->where('password',$password);
		$q=$this->db->get('tbl_teacher');
		
		//SELECT * FROM tbl_teachher WHERE username='$username' AND pword='$password';

		if ($q->num_rows()){
			return $q->row()->tid;
		}else{
			return false;
		}


	}




}